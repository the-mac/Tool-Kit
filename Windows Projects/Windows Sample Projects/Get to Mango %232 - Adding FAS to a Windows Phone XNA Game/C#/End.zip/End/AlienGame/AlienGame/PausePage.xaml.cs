﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace AlienGame
{
    public partial class PausePage : PhoneApplicationPage
    {
        // Constructor
        public PausePage()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            (App.Current as App).JumpToPauseScreen = false;

            base.OnNavigatedTo(e);
        }

        // Simple button Click event handler to take us to the game page
        private void Resume_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        // Simple button Click event handler to take us to the main menu
        private void Menu_Click(object sender, RoutedEventArgs e)
        {            
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
        }
    }
}