﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace AlienGame
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        // Remove game data and arrange the page stack when navigating to the page
        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            if ((App.Current as App).JumpToPauseScreen)
            {
                // The game page, in turn, will jump to the pause page
                NavigationService.Navigate(new Uri("/GamePage.xaml", UriKind.Relative));
                base.OnNavigatedTo(e);

                return;
            }

            if (PhoneApplicationService.Current.State.ContainsKey(App.GameStateKey))
            {
                (PhoneApplicationService.Current.State[App.GameStateKey] as GameplayHelper).UnloadContent();
                PhoneApplicationService.Current.State.Remove(App.GameStateKey);
            }

            // Backing out of this page should always exit the game
            while (NavigationService.CanGoBack)
            {
                NavigationService.RemoveBackEntry();
            }

            base.OnNavigatedTo(e);
        }

        // Simple button Click event handler to take us to the second page
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/GamePage.xaml", UriKind.Relative));
        }
    }
}