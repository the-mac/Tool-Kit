﻿namespace System.Windows.Controls
{
    using System.Collections.ObjectModel;

    internal class LinkCollection : Collection<Link>
    {
    }
}
