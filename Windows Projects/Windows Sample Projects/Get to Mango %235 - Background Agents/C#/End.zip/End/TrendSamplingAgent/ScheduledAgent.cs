﻿using Microsoft.Phone.Scheduler;
using Microsoft.Phone.Shell;
using Wazup.Helpers;
using System.IO.IsolatedStorage;
using Wazup.Services;
using System.Threading;
using System;
using System.Linq;

namespace TrendSamplingAgent
{
    public class ScheduledAgent : ScheduledTaskAgent
    {
        private const string specialToken = "cake";

        /// <summary>
        /// Looks for new tweets since the last time the trend was sampled and updates the trend tiles accordingly.
        /// Also notifies of tweets that contain the word "cake".
        /// </summary>
        /// <param name="task">
        /// The invoked task
        /// </param>
        /// <remarks>
        /// This method is called when a periodic or resource intensive task is invoked
        /// </remarks>
        protected override void OnInvoke(ScheduledTask task)
        {
            string lastTokenTrendName = null;

            int finishedRequestCount = 0;
            int secondaryTileCount = ShellTile.ActiveTiles.Count() - 1;

            ManualResetEvent requestsFinishedEvent = new ManualResetEvent(false);

            // Go over each of the pinned tiles and update them
            foreach (ShellTile activeTile in ShellTile.ActiveTiles)
            {
                string tileTrendName = UriHelper.GetTrendNameFromUri(activeTile.NavigationUri);

                if (!IsolatedStorageSettings.ApplicationSettings.Contains(tileTrendName))
                {
                    // This will happen for the main tile
                    continue;
                }

                ShellTile tileToUpdate = activeTile;
                Trend trend = (Trend)IsolatedStorageSettings.ApplicationSettings[tileTrendName];

                // Get the tweets for the trend associated with the current tile
                TwitterService.Search(trend.name, tweets =>
                    {
                        int newTweetCount = 0;                        

                        // See which tweets are new and/or contain a specific token and update the tile accordingly
                        foreach (Tweet tweet in tweets)
                        {
                            if (tweet.created_at > trend.last_tweet_fetch)
                            {
                                newTweetCount++;
                            }
                            if (tweet.text.Contains(specialToken))
                            {
                                lastTokenTrendName = trend.name;
                            }
                        }

                        trend.last_tweet_fetch = DateTime.Now;

                        StandardTileData newTileData = new StandardTileData
                        {
                            BackContent = "Updated - " + trend.last_tweet_fetch.ToShortTimeString(),
                            Count = newTweetCount,
                            BackTitle = trend.name,
                            Title = trend.name
                        };

                        tileToUpdate.Update(newTileData);

                        if (Interlocked.Increment(ref finishedRequestCount) == secondaryTileCount)
                        {
                            // Signal that all tweet updates are complete
                            requestsFinishedEvent.Set();
                        }
                    });
            }

            requestsFinishedEvent.WaitOne();

            // If we found a special token in one of the tweets, pop a toast message
            if (lastTokenTrendName != null)
            {
                ShellToast toastMessage = new ShellToast
                {
                    Title = String.Format("There is {0} in one of your tweets!", specialToken),
                    Content = String.Empty,
                    NavigationUri = UriHelper.MakeTrendUri(lastTokenTrendName)
                };

                toastMessage.Show();
            }

            NotifyComplete();
        }
    }
}
