//
//  AppDelegate.h
//  iOS Client
//
//  Created by Christopher Miller on 5/27/15.
//  Copyright (c) 2015 The MAC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

