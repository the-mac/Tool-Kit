//
//  main.m
//  iOS Client
//
//  Created by Christopher Miller on 5/27/15.
//  Copyright (c) 2015 The MAC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
